# capylabs — Frontier lab

Version 1.1 · 30 October 2026. Frontier lab was selected by Bruno. These assets implement that direction for the website, company profiles, and content.

**Selected artwork:** Quiet Profile is the logo; Pure Contour is the large capybara. Bruno confirmed both and the joined **capylabs** spelling in decision 0010. The website, guide and current download use this combination. Earlier files without the `capylabs-` prefix are historical and excluded from the current kit.

## The idea

**We build what's next.**

Apps, AI, and original media. capylabs turns advances in AI and software into useful products, then builds the brands and content around them.

## Name and endorsement

Write **capylabs** in prose and the logotype: lowercase, all together, as selected by Bruno in decision 0008. Do not use a trademark-registration symbol. The display name is not a substitute for the registered legal name on business documents.

Products may use their own names and identities, with **Built by capylabs** as a small endorsement. Subject media can use **A capylabs production**. These are implementation conventions; final product names remain separate decisions.

## Color

| Token | Value | Use |
|---|---|---|
| Midnight navy | `#071C2C` | Main canvas; text on cyan or ice |
| Ice | `#E7F6FF` | Primary text and light surfaces |
| Cyan | `#4FDFF5` | Actions, links, and the mark |
| Steel | `#A0B5C5` | Secondary text on navy |
| Deep blue | `#17617B` | Supporting graphics and surfaces; avoid small text on navy |

Use ice/navy, cyan/navy, and steel/navy for text. Keep pale cyan on a dark field; do not put it on white. Functional text must meet 4.5:1 contrast (3:1 for large text). The JSON and CSS tokens are included beside this guide.

## Typography

- **Space Grotesk:** headings, logotype, short display phrases; weights 500–700. Tight but readable tracking.
- **Manrope:** body, navigation, controls; weights 400–700. Body copy at least 16px on the website.
- Use sentence case. Keep lines under about 70 characters. Let size and space establish hierarchy.
- Both fonts are self-hosted. Source TTF, WOFF2, and SIL Open Font License files are included in `assets/fonts/`. Wordmark SVGs contain outlines and do not require an installed font.

## Mark and mascot

Quiet Profile is the selected outline head; Pure Contour is the selected standing full-body drawing. Preserve the original shaped eye, long muzzle and gentle curves. Keep navy behind the supplied animal artwork and give it breathing room. Do not add particle textures, clothes, a grin, or copy over the face.

The selected PNG source images are copied unchanged. `capylabs-lockup.svg` embeds the raster head and pairs it with outlined Space Grotesk text; it is not a fully vector-traced logo. The standalone wordmark SVGs are outlined vectors. The header/lockup has been checked in desktop and mobile website layouts. A production vector drawing and dedicated small-size refinement remain future work.

Use the full animal in the hero and the head for identity. Avoid faded edge masks that cut into the outline. No ambient animation is required.

## Voice

Say what we make. Use short sentences and concrete verbs. Let the character supply warmth.

| Use | Avoid |
|---|---|
| Apps, AI, and original media. | An innovative ecosystem of next-generation solutions. |
| A companion for live tournament poker. | Transforming the future of poker forever. |
| The engine calculates. AI explains. | AI that always knows the right answer. |
| In development. | Available now, unless verified. |

AI is central to the company, but describe its actual job. Show technical progress through the work. Do not claim benchmark leadership, a proprietary model, commercial success, or public availability without evidence.

## Layout and motion

Prefer a spacious navy canvas, large left-aligned type, and one strong animal composition. Product descriptions and statuses should be easy to scan. Avoid fake terminals, invented data, repetitive card grids, and decorative technical notation.

Motion answers an action: a button responds or a detail opens. A future character animation may use a small head tilt, blink, or curious step. Avoid perpetual particle motion. Respect reduced-motion preferences.

## Included assets

The current download contains only the selected system:

- `assets/capylabs-quiet-profile.png` — selected logo source.
- `assets/capylabs-pure-contour.png` — selected hero source.
- `assets/capylabs-lockup.{svg,png}` — raster head with outlined joined wordmark.
- `assets/capylabs-wordmark-{ice,navy,cyan}.{svg,png}` — outlined wordmarks.
- `assets/capylabs-favicon.{svg,png}`.
- `social/capylabs-avatar-512.{svg,png}`.
- `social/capylabs-cover-1500x500.{svg,png}`.
- `social/capylabs-social-card-1200x630.{svg,png}`.
- `social/capylabs-post-1080x1080.{svg,png}`.
- Licensed fonts, tokens, profile copy and these usage notes.

`tools/export-quiet-identity.py` composes the unchanged selected images and outlined type. `tools/render-quiet-identity.mjs` rasterizes those layouts. `tools/build-frontier-site.py` builds the website and filtered kit; ordinary builds do not require fonttools or resvg. Historical export scripts and non-prefixed assets preserve earlier explorations.

No social account has been changed. The prepared images are review assets.

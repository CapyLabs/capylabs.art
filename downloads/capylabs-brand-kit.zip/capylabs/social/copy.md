# Company profile copy

Drafts for the selected Frontier lab direction. Apply to verified company accounts when requested; these files do not update a social profile.

## Short bio

Apps, AI, and original media. We build what's next.

## Expanded bio

capylabs builds apps, AI tools, and original media. Currently developing a live tournament poker companion and an animated content studio.

## Company introduction

We're capylabs. We build apps, AI tools, and original media. First up: a live tournament poker companion and an animated content studio.

## Build note

The engine calculates. AI explains. That's the principle behind the poker companion we're building.

## Brazilian Portuguese

Apps, IA e conteúdo original. Estamos construindo o que vem a seguir.

A capylabs desenvolve apps, ferramentas de IA e conteúdo original. Hoje, trabalhamos em um app para torneios de poker ao vivo e um estúdio de conteúdo animado.

